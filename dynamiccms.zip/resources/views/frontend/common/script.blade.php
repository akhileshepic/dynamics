<script src="{{asset('public/frontend/js/jquery-3.2.1.slim.min.js')}}"></script>
    <script src="{{asset('public/frontend/js/popper.min.js')}}"></script>
    <script src="{{asset('public/frontend/js/bootstrap.min.js')}}"></script>
    <script src="{{asset('public/frontend/js/aos.js')}}"  ></script>
    <script>
  AOS.init();
</script>