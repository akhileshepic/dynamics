@extends('layouts.app')

@section('content')

<div class="container">
    <div class="row">
        <div class="col-md-12">
            @if (session('status'))
                <h4 class="alert alert-success">{{ session('status') }}</h4>
            @endif
            <div class="card">
                <div class="card-header">
                    <h1>Employee CRUD in Laravel 8</h1>
                    <a href="{{ url('add-employee') }}" class="btn btn-primary btn-sm float-end">Add Employee</a>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection