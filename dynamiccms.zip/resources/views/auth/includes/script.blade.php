<script src="{{ URL::asset('public/admin/assets/js/admin/jquery-3.4.1.min.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('public/admin/assets/js/admin/popper.min.js') }}"></script>
<script src="{{ URL::asset('public/admin/assets/js/admin/bootstrap.min.js') }}"></script>
<script type="text/javascript" src="{{ URL::asset('public/admin/assets/js/admin/main1.js') }}"></script>
<script type="text/javascript" src="{{ URL::asset('public/admin/assets/js/admin/parsley.min.js') }}"></script>
<script type="text/javascript" src="{{ URL::asset('public/admin/assets/js/admin/bootstrap-datepicker.min.js') }}"></script>

<script type="text/javascript" src="{{ URL::asset('public/admin/assets/js/admin/chosen.jquery.min.js') }}"></script>
<script type="text/javascript" src="{{ URL::asset('public/admin/assets/js/admin/jquery.magnific-popup.min.js') }}"></script>

<script type="text/javascript">
	$(document).ready(function(){

        setTimeout(function(){
         	$("div.alert").remove();
     	}, 5000 );
     });
</script>









