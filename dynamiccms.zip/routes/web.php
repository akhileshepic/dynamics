<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\EmployeeController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('frontend.home');
})->name('home');
Route::get('/about', function () {
    return view('frontend.about');
})->name('about');

Route::get('/service', function () {
    return view('frontend.services');
})->name('service');
Auth::routes();

Route::get('/contact', function () {
    return view('frontend.contact');
})->name('contact');
Auth::routes();



Route::namespace('Admin')->prefix('admin')->name('admin.')->group(function () {

    Route::get('login', function () {

        return view('auth.login');
    });

    Route::get('/', function () {

        return redirect('admin/login');
    })->name('login');

    Route::middleware(['auth'])->group(function () {

        //Dashboard
        Route::get('/dashboard', 'DashboardController@index')->name('dashboard');
        Route::get('/page', 'DashboardController@page')->name('page');
        Route::get('/homepage-section', 'HomepageController@homepagesetup')->name('homepage');
        Route::post('/homepage-section', 'HomepageController@homepagepost')->name('homepagepost');
        Route::match(['get', 'post'], 'changepassword', 'DashboardController@changepassword')->name('changepassword');
    });
});
Auth::routes();


Route::get('employee', [EmployeeController::class, 'index']);



Route::get('store-employee', [EmployeeController::class, 'store']);