<!DOCTYPE html>
<html lang="en">

<head>

    <?php echo $__env->yieldContent('title'); ?>
    <?php echo $__env->make('admin.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


</head>
<?php echo $__env->yieldContent('style'); ?>

<body class="c-app">



    <?php echo $__env->make('admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="c-wrapper c-fixed-components">
        <?php echo $__env->make('admin.includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="c-body">
            <main class="c-main">
                <?php echo $__env->yieldContent('body'); ?>
            </main>
            <?php echo $__env->make('admin.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>

    <?php echo $__env->yieldContent('modal'); ?>
    <?php echo $__env->make('admin.includes.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('script'); ?>
</body>

</html><?php /**PATH C:\xampp\htdocs\projects\dynamiccms\resources\views/admin/includes/main.blade.php ENDPATH**/ ?>