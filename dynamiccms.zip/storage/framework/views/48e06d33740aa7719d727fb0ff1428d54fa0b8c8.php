
<?php $__env->startSection('style'); ?>
<style>

</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>

<section id="contact" class="contact-section aos-init aos-animate" data-aos="fade-down" data-aos-easing="ease-out-c">
    <div class="container my-3">

        <div class="card">
            <div class="card-header">
                <!-- START TABS DIV -->
                <div class="tabbable-responsive">
                    <div class="tabbable">
                        <ul class="nav nav-tabs" id="myTab" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" id="first-tab" data-toggle="tab" href="#first" role="tab"
                                    aria-controls="first" aria-selected="true">Slider</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="second-tab" data-toggle="tab" href="#second" role="tab"
                                    aria-controls="second" aria-selected="false">About Us</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="third-tab" data-toggle="tab" href="#third" role="tab"
                                    aria-controls="third" aria-selected="false">Third Tab</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="fourth-tab" data-toggle="tab" href="#fourth" role="tab"
                                    aria-controls="fourth" aria-selected="false">Fourth Tab</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="fifth-tab" data-toggle="tab" href="#fifth" role="tab"
                                    aria-controls="fifth" aria-selected="false">Fifth Tab</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="sixth-tab" data-toggle="tab" href="#sixth" role="tab"
                                    aria-controls="sixth" aria-selected="false">Sixth Tab</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="card-body">


                <div class="tab-content">
                    <div class="tab-pane fade show active" id="first" role="tabpanel" aria-labelledby="first-tab">
                        <form method="post" action="<?php echo e(router('homepagepost')); ?>" enctype='multipart/form-data'>
                            <div class="col-md-12">
                                <div class="">
                                    <!-- add button -->
                                    <div class="optionBox">
                                        <form>
                                            <div class="text-right">
                                                <span class="add btn btn-primary"><i class="fa fa-plus pr-2"
                                                        aria-hidden="true"></i>Add more</span>
                                            </div>

                                            <div class="block">
                                                <div class="container py-5">
                                                    <div class="form-group">
                                                        <label for="exampleInputEmail1">Heading</label>
                                                        <input type="text" class="form-control" id="name" name="head[]"
                                                            aria-describedby="emailHelp" placeholder="heading...">

                                                    </div>
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Sub Heading</label>
                                                        <input type="text" class="form-control" id="sub_name"
                                                            name="sub_head[]" placeholder="sub heading..">
                                                    </div>
                                                    <div class="custom-file">
                                                        <input type="file" class="custom-file-input"
                                                            id="validatedCustomFile" name="image[]" required>
                                                        <label class="custom-file-label"
                                                            for="validatedCustomFile">Choose
                                                            file...</label>

                                                    </div>
                                                    <div class="form-group">
                                                        <label for="exampleFormControlTextarea1">Description</label>
                                                        <textarea class="form-control" id="exampleFormControlTextarea1"
                                                            name="description[]" rows="1"></textarea>
                                                    </div>



                                                </div>


                                            </div>
                                            <button type="submit" class="btn btn-primary">Submit</button>
                                        </form>


                                    </div>
                                </div>
                            </div>
                        </form>

                    </div>
                    <div class="tab-pane fade" id="second" role="tabpanel" aria-labelledby="second-tab">
                        <h5 class="card-title">Second Tab header</h5>
                        <p class="card-text">In hac habitasse platea dictumst. Cras sit amet massa fermentum risus
                            eleifend malesuada vel nec erat. Cras massa tellus, volutpat efficitur feugiat eu, accumsan
                            vel felis. Nullam ornare tellus eu dolor rhoncus, ut tempor lectus tincidunt. Ut in
                            condimentum lectus. Praesent non pretium mauris, efficitur condimentum ex. Nam ante lorem,
                            eleifend in egestas a, rhoncus at ex.</p>
                    </div>
                    <div class="tab-pane fade" id="third" role="tabpanel" aria-labelledby="third-tab">
                        <h5 class="card-title">Third Tab header</h5>
                        <p class="card-text">Vestibulum neque nunc, ullamcorper et laoreet in, dictum vitae nisi. Morbi
                            scelerisque cursus lobortis. Fusce a leo elit. In hac habitasse platea dictumst. Curabitur
                            aliquet nunc sed tellus rutrum ornare. Mauris euismod cursus ligula, nec mollis lorem
                            sodales vel. Proin mollis posuere nisl a pretium. Aenean sit amet nibh quis nisl pharetra
                            malesuada convallis id leo.</p>
                    </div>
                    <div class="tab-pane fade" id="fourth" role="tabpanel" aria-labelledby="fourth-tab">
                        <h5 class="card-title">Fourth Tab header</h5>
                        <p class="card-text">Nulla dignissim justo sed nulla dignissim pellentesque. Maecenas rhoncus
                            faucibus finibus. Mauris eget tincidunt metus. Morbi bibendum nunc sed nisl aliquam, sit
                            amet lacinia lectus pharetra. Cras accumsan convallis risus. Morbi nisi libero, consequat
                            eget leo vel, finibus rhoncus nulla. Mauris tempus risus quis efficitur sollicitudin.
                            Suspendisse potenti. Quisque ut leo interdum ipsum tristique ultrices.</p>
                    </div>
                    <div class="tab-pane fade" id="fifth" role="tabpanel" aria-labelledby="fifth-tab">
                        <h5 class="card-title">Fifth Tab header</h5>
                        <p class="card-text">Nunc lacinia sodales ex, in mattis nulla eleifend in. Quisque molestie,
                            dolor non egestas ornare, diam sapien accumsan erat, non malesuada nulla est ac purus. Donec
                            pharetra molestie leo sit amet posuere. Etiam feugiat mi nisi, id semper neque dignissim ut.
                            Praesent vitae accumsan eros. Curabitur a nisi non arcu suscipit rutrum at ut orci. Praesent
                            nec eros eros. Quisque tempus neque ut nibh viverra, ut commodo dolor dapibus.</p>
                    </div>
                    <div class="tab-pane fade" id="sixth" role="tabpanel" aria-labelledby="sixth-tab">
                        <h5 class="card-title">Sixth Tab header</h5>
                        <p class="card-text">Proin ornare purus vitae magna viverra suscipit. Etiam rutrum lorem cursus
                            libero scelerisque lacinia. Praesent bibendum risus id aliquam finibus. Donec sed orci
                            sodales, viverra dolor a, dignissim mi. Pellentesque nec lectus enim. Suspendisse eu ligula
                            ac tortor mollis lobortis. Nulla a laoreet neque, sit amet luctus dolor. Nam facilisis at
                            odio ac commodo. Nullam vehicula blandit dui, vel suscipit orci.</p>
                    </div>
                </div>
                <!-- END TABS DIV -->

            </div>
            <!-- <div class="card-footer p-0">
      <h5 class="text-center"><small class="text-muted">Bootstrap 4.3.1</small></h5>
    </div> -->
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
$('.add').click(function() {
    $('.block:last').before(
        '<div class="block"><div class="container py-5"><div class="form-group"><label for="exampleInputEmail1">Heading</label><input type="text" class="form-control" name="head[]" id="name" aria-describedby="emailHelp" placeholder="heading..."></div><div class="form-group"><label for="exampleInputPassword1">Sub Heading</label><input type="text" class="form-control" id="sub_name" name="sub_head[]" placeholder="sub heading.."></div><div class="custom-file"><input type="file" class="custom-file-input" id="validatedCustomFile" name="image[]" required><label class="custom-file-label" for="validatedCustomFile">Choose file...</label></div><div class="form-group"><label for="exampleFormControlTextarea1">Description</label><textarea class="form-control" id="exampleFormControlTextarea1" rows="1" name="description[]"></textarea></div></div><span class="remove btn btn-danger" style="float:right;"><i class="fa fa-trash" aria-hidden="true"></i></span></div>'
    );
});
$('.optionBox').on('click', '.remove', function() {
    $(this).parent().remove();
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.includes.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\dynamiccms\resources\views/admin/homepage/index.blade.php ENDPATH**/ ?>