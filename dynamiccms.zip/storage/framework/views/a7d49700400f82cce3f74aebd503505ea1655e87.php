<script src="<?php echo e(asset('public/frontend/js/jquery-3.2.1.slim.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/frontend/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/frontend/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/frontend/js/aos.js')); ?>"  ></script>
    <script>
  AOS.init();
</script><?php /**PATH C:\xampp\htdocs\projects\dynamiccms\resources\views/frontend/common/script.blade.php ENDPATH**/ ?>