<?php $__env->startSection('title'); ?>

<title>Dashboard</title>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('btitle'); ?>

<li class="breadcrumb-item">Dashboard</li>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

<style type="text/css">
.anchor a:hover {

    text-decoration: none;
}

.card .fa,
.card .fas {

    font-size: 60px;
    color: darkblue;

}
</style>

<div class="container-fluid">
    <div class="fade-in">
        <div class="row anchor">
            <?php if(Auth::user()->role=='admin'): ?>
            <div class="col-sm-6 col-lg-3">

            </div>
            <div class="col-sm-6 col-lg-3">

            </div>
            <div class="col-sm-6 col-lg-3">

            </div>
            <div class="col-sm-6 col-lg-3">

            </div>
            <?php endif; ?>
            <!-- /.col-->

            <!-- /.row-->
        </div>
    </div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.includes.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\dynamiccms\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>