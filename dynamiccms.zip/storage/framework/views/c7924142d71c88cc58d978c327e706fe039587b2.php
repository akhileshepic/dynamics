<script src="<?php echo e(URL::asset('public/admin/assets/js/admin/jquery-3.4.1.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(URL::asset('public/admin/assets/js/admin/popper.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('public/admin/assets/js/admin/bootstrap.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('public/admin/assets/js/admin/main1.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('public/admin/assets/js/admin/parsley.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('public/admin/assets/js/admin/bootstrap-datepicker.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('public/admin/assets/js/admin/chosen.jquery.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('public/admin/assets/js/admin/jquery.magnific-popup.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('public/admin/assets/js/admin/sweetalert.min.js')); ?>"></script>

<script type="text/javascript" src="<?php echo e(URL::asset('public/admin/assets/js/admin/jquery.email.multiple.js')); ?>"></script>

<script type="text/javascript" src="<?php echo e(URL::asset('public/admin/assets/plugins/select2/js/select2.min.js')); ?>"></script>

<script src="<?php echo e(URL::asset('public/admin/assets/js/admin/coreui.bundle.min.js')); ?>"></script>
    <!-- Plugins and scripts required by this view-->

<script src="<?php echo e(URL::asset('public/admin/assets/js/admin/coreui-utils.js')); ?>"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>

  
 
<script type="text/javascript">



		document.getElementById("year").innerHTML = new Date().getFullYear();

    

		$(document).ready(function(){

        setTimeout(function(){
         	$("div.alert").remove();
     	}, 5000 );

	    
       });

	<?php if(Session::has('message')): ?>

		  toastr.options =
		  {
		  	"closeButton" : true,
		  	"progressBar" : true
		  }
		  toastr.success("<?php echo e(session('message')); ?>");

	<?php endif; ?>

	<?php if(Session::has('password')): ?>

		  toastr.options =
		  {
		  	"closeButton" : true,
		  	"progressBar" : true
		  }
		  toastr.success("<?php echo e(session('password')); ?>");

	<?php endif; ?>

	<?php if(Session::has('error')): ?>

	  toastr.options =
	  {
	  	"closeButton" : true,
	  	"progressBar" : true
	  }
	  		toastr.error("<?php echo e(session('error')); ?>");
	<?php endif; ?>

	  <?php if(Session::has('info')): ?>
	  toastr.options =
	  {
	  	"closeButton" : true,
	  	"progressBar" : true
	  }
	  		toastr.info("<?php echo e(session('info')); ?>");
	  <?php endif; ?>

	  <?php if(Session::has('warning')): ?>
	  toastr.options =
	  {
	  	"closeButton" : true,
	  	"progressBar" : true
	  }
	  		toastr.warning("<?php echo e(session('warning')); ?>");
	  <?php endif; ?>

	<?php if(count($errors) > 0): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        	toastr.options =
			  {
			  	"closeButton" : true,
			  	"progressBar":true,
			 	"timeOut": 30000,
			  }
            toastr.error("<?php echo e($error); ?>");
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
	
	$('.sform').parsley();

	

</script>

<?php /**PATH C:\xampp\htdocs\projects\dynamiccms\resources\views/admin/includes/script.blade.php ENDPATH**/ ?>