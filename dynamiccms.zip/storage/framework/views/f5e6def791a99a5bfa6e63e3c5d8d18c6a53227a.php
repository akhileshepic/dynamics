<footer class="c-footer">
  	<div> &copy; <span id="year"></span> School Dunia</div>
  	<div class="ml-auto">Powered by&nbsp;<a target="_blank" href="http://www.epicwebtech.com">Epic Corporations</a></div>
</footer>

<?php /**PATH C:\xampp\htdocs\projects\dynamiccms\resources\views/admin/includes/footer.blade.php ENDPATH**/ ?>