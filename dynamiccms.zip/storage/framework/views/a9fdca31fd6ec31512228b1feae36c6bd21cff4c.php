<div class="c-sidebar c-sidebar-dark c-sidebar-fixed c-sidebar-lg-show" id="sidebar">

    <div class="c-sidebar-brand d-lg-down-none">
        <div class="c-sidebar-brand-full"><img src="<?php echo e(asset('public/admin/assets/img/admin/logo.png')); ?>" width="150"
                height="46"></div>
        <div class="c-sidebar-brand-minimized">SD</div>
    </div>

    <ul class="c-sidebar-nav">
        <li class="c-sidebar-nav-item"><a class="c-sidebar-nav-link" href="<?php echo e(route('admin.dashboard')); ?>">
                <i class="c-sidebar-nav-icon fa fa-tachometer"></i>Dashboard</a>
        </li>
        <li class="c-sidebar-nav-item"><a class="c-sidebar-nav-link" href="<?php echo e(route('admin.page')); ?>">
                <i class="c-sidebar-nav-icon fa fa-tachometer"></i>Page</a>
        </li>

    </ul>
    
    <button class="c-sidebar-minimizer c-class-toggler" type="button" data-target="_parent"
        data-class="c-sidebar-minimized"></button>
</div><?php /**PATH C:\xampp\htdocs\projects\dynamiccms\resources\views/admin/includes/sidebar.blade.php ENDPATH**/ ?>