<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Slider;

class HomepageController extends Controller
{
    public function homepagesetup()
    {
        return view('admin.homepage.index');
    }

    public function homepagepost(Request $request)
    {
        dd($request->all());
    }
}
